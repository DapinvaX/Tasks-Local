export const TOKEN_SECRET = 'your_jwt_secret_key_here';
export const MONGODB_URI = 'mongodb://localhost:27017/taskmanager';
export const PORT = 4000;